package com.example.augustinagilmore.juvo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class DialogSignupNotice extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_signup_notice);
        this.setFinishOnTouchOutside(false);

        final TextView ok = (TextView) findViewById(R.id.dialog_signup_notice_ok);

        ok.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) { finish();}
        });
    }
}
